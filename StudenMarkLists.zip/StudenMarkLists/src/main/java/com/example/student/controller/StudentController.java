package com.example.student.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.student.model.Student;
import com.example.student.service.StudentService;

@Controller
@SessionAttributes("selectedLanguage")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/")
	public String viewListAllPage(String keyword, Model model) {
//		model.addAttribute("listAllStudent", studentService.getStudentDetails());
//		return "listAll";

		return findPaginated(1, "id", "desc", keyword, model);
	}

	@GetMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable(value = "id") long id, RedirectAttributes redirectAttributes) {

		try {
			this.studentService.deleteStudent(id);
			redirectAttributes.addFlashAttribute("successMessage", "Item deleted successfully !!!");

		} catch (Exception e) {
//	            e.printStackTrace();
			redirectAttributes.addFlashAttribute("errorMessage", "Error deleting the item !!!");
		}
		return "redirect:/";
	}

	@GetMapping("/listById")
	public String getList(Model model, Student student) {
		model.addAttribute("student", student);
		return "llist";
	}

	@GetMapping("/updateStudent")
	public String updateStudent(@RequestParam Long id, Model model, RedirectAttributes redirectAttributes) {
//		
//		try {
		Student student = studentService.getStudentById(id);
		model.addAttribute("listById", student);
		redirectAttributes.addFlashAttribute("successMessage", "Student Detail Updated Successfully !!!");
//
//		} catch (Exception e) {
//	            e.printStackTrace();
//			redirectAttributes.addFlashAttribute("errorMessage", "Student Detail Updated Failed");
//		}
		return "llist";
	}

	@GetMapping("page/{pageNo}")
	public String findPaginated(@PathVariable(value = "pageNo") int pageNo,
			@RequestParam(value = "sortField", required = false, defaultValue = "id") String sortField,
			@RequestParam(value = "sortDirection", required = false, defaultValue = "asc") String sortDirection,
			@RequestParam(value = "keyword", required = false) String keyword, Model model) {
		int pageSize = 5;
		Page<Student> page;

		if (keyword != null && !keyword.isEmpty()) {
			// If a keyword is provided, filter the results
			page = studentService.findPaginatedWithKeyword(pageNo, pageSize, sortField, sortDirection, keyword);
		} else {
			// No keyword provided, retrieve all students
			page = studentService.findPaginated(pageNo, pageSize, sortField, sortDirection);
		}

		List<Student> listAllStudent = page.getContent();

		model.addAttribute("currentPage", pageNo);
		model.addAttribute("totalPage", page.getTotalPages());
		model.addAttribute("totalItem", page.getTotalElements());

		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("sortField", sortField);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "des" : "asc");
		model.addAttribute("listAllStudent", listAllStudent);

		return "listAll";
	}

	@GetMapping("/calculates")
	public String showForm(Model model, Student student) {
		model.addAttribute("student", student);
		student.setTamil(null);
		return "addStudent";
	}

	@PostMapping("/calculate")
	public String calculate(@ModelAttribute("student") @Valid Student student, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "addStudent";
		}
		student.setTotal(student.getTamil() + student.getEnglish() + student.getMaths() + student.getScience()
				+ student.getSocial());

		student.setAverage(student.getTotal() / 5);

		if (student.getTamil() >= 35 && student.getEnglish() >= 35 && student.getMaths() >= 35
				&& student.getScience() >= 35 && student.getSocial() >= 35) {
			if (student.getAverage() > 95) {
				student.setGrade("Excellent");
			} else if (student.getAverage() <= 95 && student.getAverage() > 85) {
				student.setGrade("Very Good");
			} else if (student.getAverage() <= 85 && student.getAverage() > 65) {
				student.setGrade("Good");
			} else if (student.getAverage() <= 65 && student.getAverage() >= 35) {
				student.setGrade("Ok");
			}
		} else {
			student.setGrade("Fail");
		}

		return "addStudent";

	}

	@GetMapping("/editStudent/{id}")
	public String editStudent(@PathVariable("id") long id, Model model) {
		Student student = studentService.getStudentById(id);
		model.addAttribute("student", student);
		return "updateStudent";
	}

	@PostMapping("/updateCalculate")
	public String updateCalculate(@ModelAttribute("student") @Valid Student student, BindingResult result,
			Model model) {
		if (result.hasErrors()) {
			return "addStudent";
		}
		student.setTotal(student.getTamil() + student.getEnglish() + student.getMaths() + student.getScience()
				+ student.getSocial());

		student.setAverage(student.getTotal() / 5);

		if (student.getTamil() >= 35 && student.getEnglish() >= 35 && student.getMaths() >= 35
				&& student.getScience() >= 35 && student.getSocial() >= 35) {
			if (student.getAverage() > 95) {
				student.setGrade("Excellent");
			} else if (student.getAverage() <= 95 && student.getAverage() > 85) {
				student.setGrade("Very Good");
			} else if (student.getAverage() <= 85 && student.getAverage() > 65) {
				student.setGrade("Good");
			} else if (student.getAverage() <= 65 && student.getAverage() >= 35) {
				student.setGrade("Ok");
			}
		} else {
			student.setGrade("Fail");
		}

		return "updateStudent";

	}

	@PostMapping("/saveStudent")
	public String addPerson(@ModelAttribute("student") Student student, RedirectAttributes redirectAttributes) {

		try {
			studentService.saveStudent(student);
			redirectAttributes.addFlashAttribute("successMessage", "Student Detail Added Successfully !!!");

		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Student Detail Added Failed !!!");
		}

		return "redirect:/";
	}

	@PostMapping("/updateStudentList")
	public String updateStudentList(@ModelAttribute("student") Student student, RedirectAttributes redirectAttributes) {

		try {
			studentService.saveStudent(student);
			redirectAttributes.addFlashAttribute("successMessage", "Student Detail Updated Successfully !!!");

		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Student Detail Updated Failed !!!");
		}

		return "redirect:/";
	}

	@GetMapping("/dashboard")
	public String goToDashBoard(@RequestParam(value = "gender", required = false, defaultValue = "All") String gender,
			Model model) {
		if ("All".equalsIgnoreCase(gender)) {
			Map<String, Long> gradeCounts = studentService.countAllGrades();
			model.addAttribute("gender", gender);
			model.addAttribute("gradeCounts", gradeCounts);
			getChatValue(model, gradeCounts);

		} else {
			Map<String, Long> gradeCounts = studentService.countGradesByGender(gender);
			model.addAttribute("gender", gender);
			model.addAttribute("gradeCounts", gradeCounts);
			getChatValue(model, gradeCounts);

		}

		return "dashboard";
	}

	@GetMapping("/grades")
	public String countGradesByGender(
			@RequestParam(value = "gender", required = false, defaultValue = "All") String gender, Model model) {
		if ("All".equalsIgnoreCase(gender)) {
			Map<String, Long> gradeCounts = studentService.countAllGrades();
			model.addAttribute("gender", gender);
			model.addAttribute("gradeCounts", gradeCounts);
			getChatValue(model, gradeCounts);

		} else {
			Map<String, Long> gradeCounts = studentService.countGradesByGender(gender);
			model.addAttribute("gender", gender);
			model.addAttribute("gradeCounts", gradeCounts);
			getChatValue(model, gradeCounts);

		}

		return "dashboard";
	}

	@SuppressWarnings("unused")
	private void getChatValue(Model model, Map<String, Long> gradeCounts) {

		Map<String, Integer> data = new LinkedHashMap<String, Integer>();

		Long okValue = gradeCounts.get("Ok");
		Long goodValue = gradeCounts.get("Good");
		Long excellentValue = gradeCounts.get("Excellent");
		Long veryGoodValue = gradeCounts.get("Very Good");
		Long failValue = gradeCounts.get("Fail");

		int intOk = okValue.intValue();
		int intGood = goodValue.intValue();
		int intexcellent;
		int intVeryGood;
		int intFail;

		if (excellentValue == null) {
			intexcellent = 0;
		} else {
			intexcellent = excellentValue.intValue();
		}
		if (veryGoodValue == null) {
			intVeryGood = 0;
		} else {
			intVeryGood = veryGoodValue.intValue();
		}
		if (goodValue == null) {
			intGood = 0;
		}
		if (okValue == null) {
			intOk = 0;
		}
		if (failValue == null) {
			intFail = 0;
		} else {
			intFail = failValue.intValue();
		}

		data.put("Excellent", intexcellent);
		data.put("Very Good", intVeryGood);
		data.put("Good", intGood);
		data.put("Ok", intOk);
		data.put("Fail", intFail);

		model.addAttribute("keySet", data.keySet());
		model.addAttribute("values", data.values());

	}

	@GetMapping("/selectedLanguage")
	public String selectLanguage(@RequestParam(value = "languages", required = false) String language, Model model) {
		model.addAttribute("selectedLang", language);

		return "redirect:/";
	}

//	@ModelAttribute("selectedLanguage")
//	public String defaultLanguage() {
//		return "redirect:/";
//	}

}
