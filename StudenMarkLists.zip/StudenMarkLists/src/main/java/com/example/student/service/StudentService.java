package com.example.student.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.example.student.model.Student;

public interface StudentService {

	List<Student> getStudentDetails();

	public void saveStudent(Student student);

	Student getStudentById(long Id);

	void deleteStudent(long Id);

	Page<Student> findPaginated(int pageNumber, int pageSize, String sortField, String sortDirection);

	Student getStudentById(String id);

	Page<Student> findPaginatedWithKeyword(int pageNumber, int pageSize, String sortField, String sortDirection,
			String keyword);
	
	public Map<String, Long> countGradesByGender(String gender);
	
	public Map<String, Long> countAllGrades();
	
}
