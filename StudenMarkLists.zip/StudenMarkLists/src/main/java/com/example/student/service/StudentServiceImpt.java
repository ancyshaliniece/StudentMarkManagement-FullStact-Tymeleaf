package com.example.student.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.example.student.exception.PageNotFontException;
import com.example.student.model.Student;
import com.example.student.repository.StudentRepository;

@Service
public class StudentServiceImpt implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	 @Autowired
	    public StudentServiceImpt(StudentRepository studentRepository) {
	        this.studentRepository = studentRepository;
	    }
	 
	@Override
	public List<Student> getStudentDetails(){
		return studentRepository.findAll();
	}

	@Override
	public void saveStudent(Student student) {
		this.studentRepository.save(student);
		
	}

	@Override
	public Student getStudentById(long Id) {
		Optional<Student> optional=studentRepository.findById(Id);
		Student student = null;
		
		if(optional.isPresent()) {
			student =optional.get();
		}else {
			throw new RuntimeException("Student Id : "+Id+" is Not Found");
		}
		return student;
	}

	@Override
	public void deleteStudent(long Id) {
		this.studentRepository.deleteById(Id);
		
	}

	@Override
	public Page<Student> findPaginated(int pageNumber, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name())?Sort.by(sortField).ascending():
			Sort.by(sortField).descending();
		
		Pageable pageable =PageRequest.of(pageNumber-1, pageSize,sort);
		
		return this.studentRepository.findAll(pageable);
	}

	@Override
	public Student getStudentById(String id) {
		Optional<Student> optional=studentRepository.findById(id);
		Student student = null;
		
		if(optional.isPresent()) {
			student =optional.get();
		}else {
			studentRepository.findById(id).orElseThrow(()->new PageNotFontException(id));
		}
		return student;
	}

	
	@Override
	 public Page<Student> findPaginatedWithKeyword(int pageNumber, int pageSize, String sortField, String sortDirection, String keyword) {
	        // Create a Pageable object for pagination
	        Pageable pageable = PageRequest.of(pageNumber - 1, pageSize, Sort.by(Sort.Direction.fromString(sortDirection), sortField));
	        
	        // Use your studentRepository to query students by keyword
	        Page<Student> students = studentRepository.findByYourFilteringCriteria(keyword, pageable);

	        return students;
	    }

//	@Override
//	public List<String> getAllGrades() {
//		List<String> grades = studentRepository.findAll()
//	            .stream()
//	            .map(Student::getGrade)
//	            .toList();
//	        return grades;
//	}

//	@Override
//	public Map<String, List<String>> calculateGradeArrays(List<String> grades) {
//		 Map<String, List<String>> gradeArrays = grades.stream()
//		            .collect(Collectors.groupingBy(grade -> grade));
//		        return gradeArrays;
//	}

//	@Override
//	public List<String> getGender() {
//		List<String> gender =studentRepository.findAll().stream().map(Student::getGender).toList();
//		return gender;
//	}

	@Override
	public Map<String, Long> countGradesByGender(String gender) {
		  List<Student> students = studentRepository.findAll();
	        return students.stream()
	            .filter(student -> student.getGender().equalsIgnoreCase(gender))
	            .collect(Collectors.groupingBy(Student::getGrade, Collectors.counting()));
	}

	@Override
	public Map<String, Long> countAllGrades() {
		List<Student> students = studentRepository.findAll();
        return students.stream()
            .collect(Collectors.groupingBy(Student::getGrade, Collectors.counting()));
	}

	
	

	
}
