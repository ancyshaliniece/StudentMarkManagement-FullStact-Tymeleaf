package com.example.student.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Student_MarkList")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@NotEmpty(message = "*Please Enter the name")
	@Column(name = "name")
	private String name;

	@NotEmpty(message = "*Please Enter the email")
	@Email
	@Column(name = "email")
	private String email;

	@NotEmpty(message = "*Please Enter the PhoneNumber")
	@Size(min = 10, message = "* Phone Number must be 10")
	@Column(name = "phoneNumber")
	private String phoneNumber;

	@NotEmpty(message = "*Please Select the gender")
	@Column(name = "gender")
	private String gender;

	@NotEmpty(message = "*Please Select the Standard")
	@Column(name = "standard")
	private String standard;

	@NotNull(message = "*Please Enter the Tamil Mark")
	@Column(name = "tamil")
	private Integer tamil;

	@NotNull(message = "*Please Enter the English Mark")
	@Column(name = "english")
	private Integer english;

	@NotNull(message = "*Please Enter the Maths Mark")
	@Column(name = "maths")
	private Integer maths;

	@NotNull(message = "*Please Enter the Science Mark")
	@Column(name = "science")
	private Integer science;

	@NotNull(message = "*Please Enter the Social Mark")
	@Column(name = "social")
	private Integer social;

	@Column(name = "total")
	private Integer total;

	@Column(name = "average")
	private double average;

	@Column(name = "grade")
	private String grade;
	
	public Student() {

	}

	public Student(long id, String name, String email, String phoneNumber, String gender, String standard, Integer tamil,
			Integer english, Integer maths, Integer science, Integer social, Integer total, double average, String grade) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.standard = standard;
		this.tamil = tamil;
		this.english = english;
		this.maths = maths;
		this.science = science;
		this.social = social;
		this.total = total;
		this.average = average;
		this.grade = grade;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public Integer getTamil() {
		return tamil;
	}

	public void setTamil(Integer tamil) {
		this.tamil = tamil;
	}

	public Integer getEnglish() {
		return english;
	}

	public void setEnglish(Integer english) {
		this.english = english;
	}

	public Integer getMaths() {
		return maths;
	}

	public void setMaths(Integer maths) {
		this.maths = maths;
	}

	public Integer getScience() {
		return science;
	}

	public void setScience(Integer science) {
		this.science = science;
	}

	public Integer getSocial() {
		return social;
	}

	public void setSocial(Integer social) {
		this.social = social;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public double getAverage() {
		return average;
	}

	public void setAverage(double average) {
		this.average = average;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	

	
}
