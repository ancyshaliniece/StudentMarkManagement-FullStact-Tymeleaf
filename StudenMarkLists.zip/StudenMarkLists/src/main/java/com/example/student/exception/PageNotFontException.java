package com.example.student.exception;

@SuppressWarnings("serial")
public class PageNotFontException extends RuntimeException{

	public  PageNotFontException(String id) {
		super("could not found the user with id "+id);
	}

}
